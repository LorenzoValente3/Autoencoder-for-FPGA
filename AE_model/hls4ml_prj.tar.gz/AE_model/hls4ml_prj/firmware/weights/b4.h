//Numpy array shape [2]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 2

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[2];
#else
model_default_t b4[2] = {0.0000000000, 0.0000000000};
#endif

#endif
