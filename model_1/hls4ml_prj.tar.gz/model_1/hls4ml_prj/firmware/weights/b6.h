//Numpy array shape [2]
//Min 0.127385094762
//Max 0.324288964272
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
model_default_t b6[2];
#else
model_default_t b6[2] = {0.1273850948, 0.3242889643};
#endif

#endif
