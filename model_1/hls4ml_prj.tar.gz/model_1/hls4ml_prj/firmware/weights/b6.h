//Numpy array shape [2]
//Min 0.055725950748
//Max 0.165406003594
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
model_default_t b6[2];
#else
model_default_t b6[2] = {0.0557259507, 0.1654060036};
#endif

#endif
